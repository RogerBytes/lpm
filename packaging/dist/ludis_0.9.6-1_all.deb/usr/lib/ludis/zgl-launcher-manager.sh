#!/bin/bash

# --- ludis launcher [slug...] [on|off] ---
#
# Enables/disables the "Ludis Launcher" (black screen + splash + gamepad lock, with an optional
# multi-executable picker) for one or more Lutris Wine/Proton games.
#
#   - "Active" means game.exe points to lpm-launch.bat, re-read from the YAML on each run (no
#     state file).
#   - "on" asks no single/multi choice: the number of entries is re-read from ludis/launcher.yml at
#     every launch (zgl-launcher-runtime.sh). It writes a first entry filled from the game.exe /
#     working_dir already set in Lutris, plus a commented example entry to adapt by hand for games
#     with several executables. It saves "original_exe", converts Linux paths to Windows paths
#     (C:\...) by text replacement for drive_c paths (winepath only outside drive_c), and points
#     game.exe to lpm-launch.bat. No relay and no Lutris prelaunch command: the orchestrator writes
#     lpm-launch.bat before launching (the relay of ludis <= 0.9.5 is removed, see
#     zgl-launcher-legacy.sh). No default splash is copied: without ludis/images/splash/splash.png
#     the loading screen is plain black.
#   - "off" restores the original exe ("original_exe", else the first entry's exe), removes
#     prelaunch_command only if it references the old relay, then deletes what the launcher added:
#     ludis/launcher.yml (the entries go with it), scripts/lpm-launcher.sh (old format), every
#     lpm-launch.bat. It never touches ludis/images, the other files of ludis/scripts or any game file.
#   - Wine/Proton games only (runner='wine'), shared prefixes included (non-destructive).
#   - "--if-needed" (before or after the slugs): a game already in the requested state is skipped
#     instead of failing the command. Used by the GUI (page_launcher), where the state follows from
#     the form content.
#   - "ludis launcher status" (no slug): prints the slugs of games that have the launcher active (same
#     detection, zgp_launcher_is_active); modifies nothing. Used by the GUI to highlight them.
#      nothing. Added for "gui/*.py" (page_launcher) to highlight (bold) active games in the
#      selection list.

cli_args=("$@")
if_needed=0
_filtered_args=()
for _a in "${cli_args[@]}"; do
  if [[ "${_a}" = "--if-needed" ]]; then
    if_needed=1
  else
    _filtered_args+=("${_a}")
  fi
done
cli_args=("${_filtered_args[@]}")

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./zgl-lang-loader.sh
source "${script_dir}/zgl-lang-loader.sh"
# shellcheck source=./zgu-cli-utils.sh
source "${script_dir}/zgu-cli-utils.sh"
# shellcheck source=./zgu-lutris-utils.sh
source "${script_dir}/zgu-lutris-utils.sh"
# shellcheck source=./zgu-games-cli.sh
source "${script_dir}/zgu-games-cli.sh"
# shellcheck source=./zgu-log-utils.sh
source "${script_dir}/zgu-log-utils.sh"
# shellcheck source=./zgu-ludis-paths.sh
source "${script_dir}/zgu-ludis-paths.sh"

# --- 0. CLI syntax validation (bin/ludis has no interactive entry point: no menu/Zenity
# selection, only this explicit terminal command) ---
cli_action=""
cli_slugs=()

last_arg="${cli_args[-1]:-}"
if [[ "${last_arg}" = "off" ]] || [[ "${last_arg}" = "on" ]]; then
  cli_action="${last_arg}"
  cli_slugs=("${cli_args[@]:0:$(( ${#cli_args[@]} - 1 ))}")
elif [[ ${#cli_args[@]} -eq 1 ]] && [[ "${cli_args[0]}" = "status" ]]; then
  # See item 7 of the file header: no slug required, read-only.
  cli_action="status"
fi
if [[ -z "${cli_action}" ]]; then
  zgu_cli_error "$(t launcher.cli_usage)"
  exit 1
fi
if [[ "${cli_action}" != "status" ]] && [[ ${#cli_slugs[@]} -eq 0 ]]; then
  zgu_cli_error "$(t launcher.cli_usage)"
  exit 1
fi

zgp_launcher_report_error_early() {
  local msg="$1"
  echo "${msg}" >&2
}

for cmd in python3 sqlite3; do
  if ! command -v "${cmd}" >/dev/null 2>&1; then
    zgp_launcher_report_error_early "$(t launcher.cmd_missing "${cmd}")"
    exit 1
  fi
done
if ! python3 -c "import yaml" >/dev/null 2>&1; then
  zgu_cli_error "$(t launcher.pyyaml_missing_cli)"
  exit 1
fi

# --- 1. Flatpak vs native package detection + Lutris path resolution ---

zgu_load_lutris_env || {
  zgp_launcher_report_error_early "$(t launcher.lutris_missing)"
  exit 1
}

if [[ ! -f "${lutris_db}" ]]; then
  zgp_launcher_report_error_early "$(t launcher.db_missing "${lutris_db}")"
  exit 1
fi

# --- 2. Enable/disable choice (CLI only) ---
action="${cli_action}"

# --- 3. List of Wine/Proton games, filtered by current state in the YAML ---
zgp_games_load launcher zgp_launcher_report_error_early

# Returns 0 (true) if game.exe already points to lpm-launch.bat: that is all the current
# format needs (no relay, no Lutris prelaunch command: the orchestrator writes the .bat before
# launching, see lib/zgl-launcher-orchestrator.sh). Games in the old format (also with a
# prelaunch command pointing to scripts/lpm-launcher.sh) are therefore active too, and are
# converted at their first launch (lib/zgl-launcher-legacy.sh).
zgp_launcher_is_active() {
  local configpath="$1" yml_file
  [[ -z "${configpath}" ]] && return 1
  yml_file="${lutris_config_dir}/${configpath}.yml"
  [[ -f "${yml_file}" ]] || return 1
  YML_PATH="${yml_file}" python3 -c '
import os, sys, yaml
try:
    with open(os.environ["YML_PATH"], "r") as f:
        data = yaml.safe_load(f) or {}
    exe = (data.get("game") or {}).get("exe") or ""
    sys.exit(0 if os.path.basename(exe) == "lpm-launch.bat" else 1)
except Exception:
    sys.exit(1)
' 2>/dev/null
}

zgp_games_toggle_targets launcher zgp_launcher_is_active

# --- 4. Apply: enable ---
# Step state of zgp_launcher_apply_on (globals la_*, same pattern as zgp_isolate_one).
la_exe="" la_workdir="" la_prefix="" la_version=""
la_win_exe="" la_win_workdir="" la_bat_dir="" la_bat_path=""
la_drive_c_root="" la_winepath_bin="" la_winepath_resolved=0

# Reads exe/workdir/prefix/version of the Lutris yml into la_*. Args: slug yml_file game_dir.
zgp_launcher_read_state() {
  local slug="$1" yml_file="$2" game_dir="$3"
  # Reads the current exe/working_dir/prefix/version and resolves the effective working_dir
  # exactly like Lutris (explicit working_dir, else the exe folder; see Lutris source
  # lutris/runners/wine.py, _get_explicit_working_dir()).
  local current_data
  current_data=$(YML_PATH="${yml_file}" GAME_PATH="${game_dir}" python3 -c '
import os, sys, yaml

with open(os.environ["YML_PATH"], "r") as f:
    data = yaml.safe_load(f) or {}

game = data.get("game") or {}
exe = str(game.get("exe") or "")
if exe and not os.path.isabs(exe):
    exe = os.path.join(os.environ.get("GAME_PATH",""), exe)

working_dir = str(game.get("working_dir") or "")
if not working_dir and exe:
    working_dir = os.path.dirname(exe)

prefix = str(game.get("prefix") or "")
version = str((data.get("wine") or {}).get("version") or "")

if not exe:
    sys.exit(1)

print(exe)
print(working_dir)
print(prefix)
print(version)
' 2>/dev/null)

  if [[ -z "${current_data}" ]]; then
    zgp_launcher_report_error_early "$(t launcher.no_current_exe "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=no_current_exe"
    return 1
  fi
  { IFS= read -r la_exe; IFS= read -r la_workdir; IFS= read -r la_prefix; IFS= read -r la_version; } <<< "${current_data}"
  [[ -z "${la_prefix}" ]] && la_prefix="${game_dir}"
  return 0
}

# Linux -> Windows path conversion (see comments in zgp_launcher_resolve_windows_paths).
zgp_launcher_to_windows_path() {
  local linux_path="$1" rel
  if [[ "${linux_path}" = "${la_drive_c_root}" ]]; then
    printf 'C:\\\n'
    return 0
  fi
  if [[ "${linux_path}" = "${la_drive_c_root}/"* ]]; then
    rel="${linux_path#"${la_drive_c_root}"/}"
    printf 'C:\\%s\n' "${rel//\//\\}"
    return 0
  fi
  if [[ "${la_winepath_resolved}" -eq 0 ]]; then
    la_winepath_resolved=1
    local wine_bin
    wine_bin=$(zgu_get_wine_binary "${runner_dir}" "${la_version}" 2>/dev/null)
    if [[ -n "${wine_bin}" ]] && [[ -x "$(dirname "${wine_bin}")/winepath" ]]; then
      la_winepath_bin="$(dirname "${wine_bin}")/winepath"
    elif command -v winepath >/dev/null 2>&1; then
      la_winepath_bin="winepath"
    fi
  fi
  [[ -n "${la_winepath_bin}" ]] || return 1
  WINEPREFIX="${la_prefix}" "${la_winepath_bin}" -w "${linux_path}" 2>/dev/null | tr -d '\r'
}

# Converts exe/workdir to Windows paths into la_win_*. Arg: slug.
zgp_launcher_resolve_windows_paths() {
  local slug="$1"
  # Linux -> Windows path conversion. A path inside "<prefix>/drive_c" is converted by plain
  # text replacement ("<prefix>/drive_c/Games/x.exe" -> "C:\Games\x.exe"): no Wine process is
  # started (winepath would start wineserver and could pop up a Wine window, e.g. "updating the
  # prefix", just to write a YAML file). Same rule as zgl-launcher-entries.sh.
  # "winepath" is only the fallback for a path outside drive_c (other drive letter): first the
  # one next to the wine binary of the runner used by this game, else a generic one from PATH.
  la_drive_c_root="${la_prefix%/}/drive_c"
  la_winepath_bin=""; la_winepath_resolved=0
  la_win_exe=$(zgp_launcher_to_windows_path "${la_exe}")
  la_win_workdir=$(zgp_launcher_to_windows_path "${la_workdir}")

  if [[ -z "${la_win_exe}" ]] || [[ -z "${la_win_workdir}" ]]; then
    zgp_launcher_report_error_early "$(t launcher.winepath_failed "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=winepath_failed"
    return 1
  fi
  return 0
}

# Computes la_bat_dir / la_bat_path. Arg: slug.
zgp_launcher_compute_bat_dir() {
  local slug="$1"
  # FIXED location of lpm-launch.bat, INSIDE drive_c (never the prefix root): Lutris runs a ".bat"
  # with its folder as working directory, and a folder outside drive_c is reachable from Wine
  # only through a Z: drive, often missing in per-game prefixes (the game would not start).
  # Chosen root: the direct subfolder of "drive_c/Games/" that contains the exe at any depth, not
  # "working_dir" (may be unset) nor "dirname(exe)" (may be very deep). Example: exe in
  # drive_c/Games/Jeu/a/b/c/exe gives drive_c/Games/Jeu/lpm-launch.bat.
  local drive_c games_root
  drive_c="${la_prefix}/drive_c"
  games_root="${drive_c}/Games"

  if [[ "${la_exe}" = "${games_root}/"* ]]; then
    local rel_to_games top_component
    rel_to_games="${la_exe#"${games_root}"/}"
    top_component="${rel_to_games%%/*}"
    la_bat_dir="${games_root}/${top_component}"
  else
    # Fallback: install outside the drive_c/Games/<game>/... convention, so the rule above
    # cannot apply. Uses "la_workdir" (resolved above: explicit config working_dir, else
    # dirname(exe)), and logs it.
    la_bat_dir="${la_workdir}"
    zgu_log "launcher" "WARN" "slug=${slug} reason=exe_outside_games_convention bat_dir=${la_bat_dir}"
  fi

  la_bat_path="${la_bat_dir}/lpm-launch.bat"
}

# Writes lpm-launch.bat at activation.
zgp_launcher_write_bat() {
  # Writes lpm-launch.bat NOW, at activation, not only at the first real launch
  # (zgl-launcher-runtime.sh rewrites it anyway with the chosen entry). Required: "game.exe"
  # is pointed to this path below, in this same activation; if the file does not exist yet,
  # Lutris reports it missing/misbehaves before the first launch. Same content as the template
  # of zgl-launcher-runtime.sh, with the default auto-filled entry (la_win_workdir/la_win_exe,
  # resolved above).
  mkdir -p "${la_bat_dir}" 2>/dev/null
  {
    printf '@echo off\r\n'
    printf 'cd /d "%s"\r\n' "${la_win_workdir}"
    printf 'start "" "%s"\r\n' "${la_win_exe}"
  } > "${la_bat_path}" 2>/dev/null
}

# Creates ludis/launcher.yml with the auto-filled entry + a commented example. Args: slug
# launcher_yml. Returns 1 on failure.
zgp_launcher_create_launcher_yml() {
  local slug="$1" launcher_yml_on="$2"
  mkdir -p "$(dirname "${launcher_yml_on}")" 2>/dev/null
  local default_label
  default_label="$(t launcher.default_entry_label)"

  YML_PATH="${launcher_yml_on}" TITLE="${name_by_slug[${slug}]}" PROMPT="$(t launcher.default_prompt)" \
    LABEL="${default_label}" WORKDIR="${la_win_workdir}" EXE="${la_win_exe}" ORIGINAL_EXE="${la_exe}" \
    BAT_PATH_LINUX="${la_bat_path}" python3 -c '
import os, yaml

data = {
    "title": os.environ["TITLE"],
    "prompt": os.environ["PROMPT"],
    "original_exe": os.environ["ORIGINAL_EXE"],
    "bat_path": os.environ["BAT_PATH_LINUX"],
    "entries": [
        {"label": os.environ["LABEL"], "workdir": os.environ["WORKDIR"], "exe": os.environ["EXE"]},
    ],
}
with open(os.environ["YML_PATH"], "w") as f:
    yaml.dump(data, f, sort_keys=False, allow_unicode=True)
' 2>/dev/null
  if [[ $? -ne 0 ]]; then
    zgp_launcher_report_error_early "$(t launcher.yaml_write_failed "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=yaml_write_failed"
    return 1
  fi

  {
    echo "# $(t launcher.example_entry_comment)"
    echo "#  - label: \"$(t launcher.example_entry_label)\""
    echo "#    workdir: \"C:\\\\Games\\\\...\""
    echo "#    exe: \"C:\\\\Games\\\\...\\\\game.exe\""
  } >> "${launcher_yml_on}"
  return 0
}

# Brings the two keys ludis relies on up to date in an existing ludis/launcher.yml. Args: slug
# launcher_yml. Returns 1 on failure.
zgp_launcher_update_launcher_yml() {
  local slug="$1" launcher_yml_on="$2"
  # ludis/launcher.yml already exists (hand-written, restored from a .zgp, or left by an earlier
  # "off"): its entries are kept, but the two keys ludis relies on are updated (they hold absolute
  # Linux paths, wrong after an import on another machine):
  #  - "bat_path": where Lutris REALLY runs lpm-launch.bat. If stale, the runtime rewrites another
  #    file than the one Lutris runs and the picker seems to ignore the choice.
  #  - "original_exe": the exe to restore on "off". Only set when game.exe does not already point to
  #    an lpm-launch.bat, and an existing value is never overwritten with the .bat.
  # Comment lines at the end of the file are kept.
  YML_PATH="${launcher_yml_on}" ORIGINAL_EXE="${la_exe}" \
    BAT_PATH_LINUX="${la_bat_path}" python3 -c '
import os, yaml

path = os.environ["YML_PATH"]
with open(path, "r") as f:
    text = f.read()
data = yaml.safe_load(text)
if not isinstance(data, dict):
    raise SystemExit(1)

changed = False
if data.get("bat_path") != os.environ["BAT_PATH_LINUX"]:
    data["bat_path"] = os.environ["BAT_PATH_LINUX"]
    changed = True
original = os.environ["ORIGINAL_EXE"]
if os.path.basename(original) != "lpm-launch.bat" and data.get("original_exe") != original:
    data["original_exe"] = original
    changed = True

if changed:
    comments = [l for l in text.splitlines() if l.lstrip().startswith("#")]
    out = yaml.dump(data, sort_keys=False, allow_unicode=True, width=1000000)
    if comments:
        out += "\n".join(comments) + "\n"
    with open(path, "w") as f:
        f.write(out)
' 2>/dev/null
  if [[ $? -ne 0 ]]; then
    zgp_launcher_report_error_early "$(t launcher.yaml_write_failed "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=yaml_update_failed"
    return 1
  fi
  return 0
}

# Creates or updates ludis/launcher.yml. Args: slug game_dir.
zgp_launcher_write_launcher_yml() {
  local slug="$1" game_dir="$2"
  # --- Write ludis/launcher.yml (auto-filled entry + commented example) --
  # ONLY if it does not exist yet. "off" deletes it (item 4 of the file header), so a file
  # that exists here comes from a hand edit or a restored .zgp; overwriting it on "on" would
  # lose that customization, including on a repair re-enable after a reinstall that dropped
  # system.prelaunch_command (see zgp_launcher_is_active above). ---
  local launcher_yml_on
  launcher_yml_on="$(zgu_ludis_find "${game_dir}" launcher)"
  if [[ ! -f "${launcher_yml_on}" ]]; then
    zgp_launcher_create_launcher_yml "${slug}" "${launcher_yml_on}" || return 1
  else
    zgp_launcher_update_launcher_yml "${slug}" "${launcher_yml_on}" || return 1
  fi
  return 0
}

# Points game.exe of the Lutris yml to lpm-launch.bat. Args: slug yml_file.
zgp_launcher_wire_lutris_yml() {
  local slug="$1" yml_file="$2"
  # --- Wiring into the Lutris config: ONLY game.exe -> lpm-launch.bat ---
  #
  # No relay script, no system.prelaunch_command: the orchestrator (entry point of every ludis
  # shortcut) writes lpm-launch.bat itself, on the host, before Lutris starts. No splash image is
  # copied either: a missing "${game_dir}/ludis/images/splash/splash.png" means "plain black loading screen",
  # and an existing one is never touched.
  #
  # Line-based text editing (zgu-yaml-edit.py): yaml.dump would destroy the Lutris YAML comments,
  # including hooks disabled by Ludis ("# lpm:hook-disabled"). Falls back to the full rewrite
  # below if targeted editing is not possible.
  if python3 "${script_dir}/zgu-yaml-edit.py" "${yml_file}" set game exe "${la_bat_path}" >/dev/null 2>&1; then
    :
  else
    YML_PATH="${yml_file}" BAT_PATH="${la_bat_path}" python3 -c '
import os, yaml

yml_path = os.environ["YML_PATH"]
with open(yml_path, "r") as f:
    data = yaml.safe_load(f) or {}

if "game" not in data or not isinstance(data.get("game"), dict):
    data["game"] = {}
data["game"]["exe"] = os.environ["BAT_PATH"]

with open(yml_path, "w") as f:
    yaml.dump(data, f, sort_keys=False)
' 2>/dev/null
  fi
  if [[ $? -ne 0 ]]; then
    zgp_launcher_report_error_early "$(t launcher.yaml_patch_failed "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=lutris_yaml_patch_failed"
    return 1
  fi
  return 0
}

zgp_launcher_apply_on() {
  local slug="$1" game_dir="$2" configpath="$3"
  local yml_file="${lutris_config_dir}/${configpath}.yml"

  if [[ ! -f "${yml_file}" ]]; then
    zgp_launcher_report_error_early "$(t launcher.yml_missing "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=yaml_not_found"
    return 1
  fi

  zgp_launcher_read_state "${slug}" "${yml_file}" "${game_dir}" || return 1
  zgp_launcher_resolve_windows_paths "${slug}" || return 1
  zgp_launcher_compute_bat_dir "${slug}"
  zgp_launcher_write_bat
  zgp_launcher_write_launcher_yml "${slug}" "${game_dir}" || return 1
  zgp_launcher_wire_lutris_yml "${slug}" "${yml_file}" || return 1

  # A relay of the old format (ludis <= 0.9.5) left in this game is removed (and bat_path of
  # ludis/launcher.yml aligned on game.exe).
  bash "${script_dir}/zgl-launcher-legacy.sh" "${yml_file}" "${game_dir}" >/dev/null 2>&1

  zgu_log "launcher" "OK" "slug=${slug} action=on"

  # The path of ludis/launcher.yml to edit by hand is already given by zgu_cli_ok in the calling
  # loop; no folder-opening offer via Zenity here (bin/ludis has no interactive entry point).

  return 0
}

# --- 5. Apply: disable ---
# Finds the exe to restore into off_original_exe: "original_exe" of ludis/launcher.yml, else rebuilt
# from the first entry. Args: slug game_dir yml_file launcher_yml. Returns 1 if nothing found.
off_original_exe=""
zgp_launcher_find_original_exe() {
  local slug="$1" game_dir="$2" yml_file="$3" launcher_yml="$4"
  off_original_exe=$(YML_PATH="${launcher_yml}" python3 -c '
import os, yaml
with open(os.environ["YML_PATH"], "r") as f:
    data = yaml.safe_load(f) or {}
print(data.get("original_exe") or "")
' 2>/dev/null)

  if [[ -z "${off_original_exe}" ]]; then
    # No saved original exe (file written by hand or by a very old ludis): fall back on the exe of the
    # FIRST menu entry, which is nearly always the game's original exe, converted from its Windows
    # path to the Linux path Lutris expects (only "C:\..." is convertible: pure text, no Wine).
    off_original_exe=$(YML_PATH="${launcher_yml}" LUTRIS_YML="${yml_file}" GAME_DIR="${game_dir}" python3 -c '
import os, yaml

try:
    with open(os.environ["YML_PATH"], "r") as f:
        data = yaml.safe_load(f) or {}
    entries = data.get("entries") or []
    exe = ""
    for e in entries:
        if isinstance(e, dict) and e.get("exe"):
            exe = str(e["exe"])
            break
    if exe[:3].upper() != "C:\\":
        raise SystemExit(0)
    prefix = ""
    try:
        with open(os.environ["LUTRIS_YML"], "r") as f:
            prefix = str(((yaml.safe_load(f) or {}).get("game") or {}).get("prefix") or "")
    except Exception:
        pass
    prefix = (prefix or os.environ["GAME_DIR"]).rstrip("/")
    print(prefix + "/drive_c/" + exe[3:].replace("\\", "/"))
except SystemExit:
    raise
except Exception:
    pass
' 2>/dev/null)
    if [[ -z "${off_original_exe}" ]]; then
      zgp_launcher_report_error_early "$(t launcher.no_original_exe "${slug}")"
      zgu_log "launcher" "ERROR" "slug=${slug} reason=original_exe_missing"
      return 1
    fi
    echo "$(t launcher.original_exe_fallback "${name_by_slug[${slug}]}" "${off_original_exe}")" >&2
    zgu_log "launcher" "WARN" "slug=${slug} reason=original_exe_from_first_entry exe=${off_original_exe}"
  fi
  return 0
}

# Restores game.exe (and drops the relay prelaunch of an old format) in the Lutris yml.
# Args: slug yml_file. Uses off_original_exe. Returns 1 on failure.
zgp_launcher_restore_lutris_yml() {
  local slug="$1" yml_file="$2"
  local original_exe="${off_original_exe}"
# Line-based text editing (zgu-yaml-edit.py), see zgp_launcher_apply_on above.
if {
  yaml_edit_py="${script_dir}/zgu-yaml-edit.py"
  python3 "${yaml_edit_py}" "${yml_file}" set game exe "${original_exe}" &&
  current_prelaunch=$(YML_PATH="${yml_file}" python3 -c '
import os, yaml
with open(os.environ["YML_PATH"], "r") as f:
    data = yaml.safe_load(f) or {}
system = data.get("system")
print(str(system.get("prelaunch_command") or "") if isinstance(system, dict) else "")
') &&
  if [[ "${current_prelaunch}" == *"scripts/lpm-launcher.sh"* ]]; then
    python3 "${yaml_edit_py}" "${yml_file}" unset system prelaunch_command &&
    python3 "${yaml_edit_py}" "${yml_file}" unset system prelaunch_wait
  fi
} >/dev/null 2>&1; then
  :
else
  YML_PATH="${yml_file}" ORIGINAL_EXE="${original_exe}" RELAY_MARKER="scripts/lpm-launcher.sh" python3 -c '
import os, yaml

yml_path = os.environ["YML_PATH"]
with open(yml_path, "r") as f:
    data = yaml.safe_load(f) or {}

if "game" not in data or not isinstance(data.get("game"), dict):
    data["game"] = {}
data["game"]["exe"] = os.environ["ORIGINAL_EXE"]

system = data.get("system")
if isinstance(system, dict):
    current = str(system.get("prelaunch_command") or "")
    if os.environ["RELAY_MARKER"] in current:
        system.pop("prelaunch_command", None)
        system.pop("prelaunch_wait", None)

with open(yml_path, "w") as f:
    yaml.dump(data, f, sort_keys=False)
' 2>/dev/null
fi
  if [[ $? -ne 0 ]]; then
    zgp_launcher_report_error_early "$(t launcher.yaml_patch_failed "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=lutris_yaml_patch_failed"
    return 1
  fi
  return 0
}

# Removes the files the launcher itself added. Args: game_dir launcher_yml.
zgp_launcher_remove_files() {
  local game_dir="$1" launcher_yml="$2"
  # --- Removal of the files the Ludis Launcher itself added (only AFTER the Lutris config was
  # restored above). Exactly these, by name, nothing else:
  #   <game dir>/lpm-launcher.yml, <game dir>/scripts/lpm-launcher.sh,
  #   every "lpm-launch.bat" (the one named by "bat_path", the one at the root of the game
  #   folder, and the ones in <game dir>/drive_c/Games/*/), and the temporary
  #   .lpm-launcher-choice.
  # Never touched: the game files, anything else inside the prefix (Windows files), splash/
  # and the other files of scripts/ (loading screen: lpm-winetrace*), which are not the
  # launcher's. "scripts/" is removed only if it ends up empty (rmdir). ---
  local bat_in_yml bat_file
  bat_in_yml=$(YML_PATH="${launcher_yml}" python3 -c '
import os, yaml
with open(os.environ["YML_PATH"], "r") as f:
    data = yaml.safe_load(f) or {}
print(data.get("bat_path") or "")
' 2>/dev/null)

  for bat_file in "${bat_in_yml}" "${game_dir}/lpm-launch.bat" "${game_dir}"/drive_c/Games/*/lpm-launch.bat; do
    [[ -n "${bat_file}" ]] || continue
    [[ "$(basename "${bat_file}")" = "lpm-launch.bat" ]] || continue
    [[ -f "${bat_file}" ]] && rm -f -- "${bat_file}"
  done
  rm -f -- "${game_dir}/scripts/lpm-launcher.sh" 2>/dev/null
  zgu_ludis_remove "${game_dir}" launcher
  zgu_ludis_remove "${game_dir}" launcher_choice
  rmdir "${game_dir}/scripts" 2>/dev/null
  zgu_ludis_prune "${game_dir}"
}

zgp_launcher_apply_off() {
  local slug="$1" game_dir="$2" configpath="$3"
  local yml_file="${lutris_config_dir}/${configpath}.yml"
  local launcher_yml
  launcher_yml="$(zgu_ludis_find "${game_dir}" launcher)"

  if [[ ! -f "${launcher_yml}" ]]; then
    zgp_launcher_report_error_early "$(t launcher.launcher_yml_missing "${slug}")"
    zgu_log "launcher" "ERROR" "slug=${slug} reason=ludis_launcher_yml_not_found"
    return 1
  fi

  zgp_launcher_find_original_exe "${slug}" "${game_dir}" "${yml_file}" "${launcher_yml}" || return 1
  zgp_launcher_restore_lutris_yml "${slug}" "${yml_file}" || return 1
  zgp_launcher_remove_files "${game_dir}" "${launcher_yml}"

  zgu_log "launcher" "OK" "slug=${slug} action=off"
  return 0
}

exit_code=0
n_ok=0
for target_slug in "${targets[@]}"; do
  if [[ "${action}" = "on" ]]; then
    if zgp_launcher_apply_on "${target_slug}" "${dir_by_slug[${target_slug}]}" "${configpath_by_slug[${target_slug}]}"; then
      n_ok=$(( n_ok + 1 ))
      zgu_cli_ok "$(t launcher.done_one_on_cli "${name_by_slug[${target_slug}]}" "$(zgu_ludis_find "${dir_by_slug[${target_slug}]}" launcher)")"
    else
      exit_code=1
    fi
  else
    if zgp_launcher_apply_off "${target_slug}" "${dir_by_slug[${target_slug}]}" "${configpath_by_slug[${target_slug}]}"; then
      n_ok=$(( n_ok + 1 ))
      zgu_cli_ok "$(t launcher.done_one_off_cli "${name_by_slug[${target_slug}]}")"
    else
      exit_code=1
    fi
  fi
done

exit "${exit_code}"

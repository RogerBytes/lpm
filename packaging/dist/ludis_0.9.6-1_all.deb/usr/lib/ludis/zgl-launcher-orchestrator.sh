#!/bin/bash

# --- ludis launcher: SINGLE entry point of all shortcuts (.desktop) created by ludis ---
#
# Called directly by "Exec=" of the .desktop (see zgu_write_game_shortcut in
# zgu-desktop-utils.sh), identical for all Wine games, with or without the Ludis Launcher
# (multi-entry "picker"). Role: show the loading background (black, or splash/splash.png if
# present) with a small "loading" indicator (translated text + spinner) at the bottom right,
# never covered by a banner, THEN hand over to Lutris for the real launch.
#
# Usage: zgl-launcher-orchestrator.sh <game_id> <version:package|flatpak>
#
# Deliberately only TWO arguments, both safe without escaping (an integer, a fixed word):
# "slug"/"game_dir" never go through the .desktop "Exec=", whose escaping rules differ from
# a shell's and where a path with spaces would be an unnecessary risk. This script queries
# the Lutris database (pga.db) itself to get "slug"/"directory" from "game_id", with the same
# query, base paths and "games_dir/slug" fallback as zgp-game-shortcutter.sh /
# zgp-game-installer.sh (see zgu-lutris-utils.sh).
#
# Design:
#   - Loading screen enabled for ALL ludis shortcuts by default; disabled per game by the
#     presence of "${game_dir}/ludis/settings/no-loadingscreen" ("Loading screen" checkbox unchecked
#     when creating/regenerating the shortcut, see zgp-game-shortcutter.sh /
#     zgp-game-installer.sh). Then: direct launch, zero overhead.
#   - The multi-entry picker (several executables per game) is shown HERE, embedded in the
#     loading screen; then THIS script runs zgl-launcher-runtime.sh (on the host, before
#     Lutris) which writes lpm-launch.bat with the chosen entry. There is no Lutris
#     prelaunch command any more. Games made by ludis <= 0.9.5 (relay + prelaunch command) are
#     converted here at their first launch, see zgl-launcher-legacy.sh (DO NOT REMOVE that
#     conversion: old packages can be installed years later). The picker reuses the
#     background already opened by THIS script (fixed-path control file below).
#   - Once the background is up, this script "exec"s the normal Lutris command (the same as
#     the one used in Exec= before the orchestrator): the bash process is replaced by lutris
#     (same PID), so no wrapper stays in the process tree and window/dock tracking
#     (WM_CLASS, StartupWMClass) is unaffected.
#   - No check/closing of an already-running Lutris instance: end of loading is detected by
#     the appearance of THE GAME WINDOW (detached watcher below), not by the end of the
#     Lutris process. "lutris lutris:rungameid/<id>" really launches the game either way;
#     only the blocking behaviour of the calling process differs, and it is not used.

set -u

game_id="${1:-}"
version="${2:-}"

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./zgl-lang-loader.sh
source "${script_dir}/zgl-lang-loader.sh"
# shellcheck source=./zgu-log-utils.sh
source "${script_dir}/zgu-log-utils.sh"
# shellcheck source=./zgu-ludis-paths.sh
source "${script_dir}/zgu-ludis-paths.sh"
# shellcheck source=./zgu-lutris-utils.sh
source "${script_dir}/zgu-lutris-utils.sh"

# --- Automatic saves (see lib/zgp-game-saves.sh): when a sync folder is set and the mode is on for
# this game, bring a newer backup (another machine or session) BEFORE the game starts, then let a
# detached monitor copy the saves every N minutes and once more when the game has ended. The local
# saves are always kept in previous/ first. Never blocks the launch for long (60 s at most).
# Called by launch_lutris, which every path of this script ends with, so no launch escapes it. ---
saves_auto_start() {
  local out
  [[ -n "${slug:-}" && -n "${game_dir:-}" && -d "${game_dir}" ]] || return 0
  pkill -f "zgu-saves-monitor.py" 2>/dev/null
  zgu_saves_auto_wanted "${game_dir}" && command -v python3 >/dev/null 2>&1 || return 0
  out="$(timeout 60 bash "${script_dir}/zgp-game-saves.sh" "${slug}" pull 2>&1 </dev/null | tail -n 1)"
  zgu_log "launcher-orchestrator" "INFO" "slug=${slug} saves ${out:-pull=nothing}"
  python3 "${script_dir}/zgu-saves-monitor.py" "${game_dir}" "${slug}" "$(zgu_saves_interval)" >/dev/null 2>&1 </dev/null &
  disown $! 2>/dev/null
  return 0
}

# --- Final Lutris command: the same as the one used in Exec= before the orchestrator ---
overlay_flatpak_env=()
launch_lutris() {
  saves_auto_start
  if [[ "${version}" = "flatpak" ]]; then
    exec env LUTRIS_SKIP_INIT=1 flatpak run ${overlay_flatpak_env[@]+"${overlay_flatpak_env[@]}"} net.lutris.Lutris "lutris:rungameid/${game_id}"
  else
    exec env LUTRIS_SKIP_INIT=1 lutris "lutris:rungameid/${game_id}"
  fi
  # "exec" never returns on success: reaching here means exec failed (lutris/flatpak not
  # found); last resort, log and exit with an error.
  zgu_log "launcher-orchestrator" "ERROR" "game_id=${game_id} reason=lutris_exec_failed"
  exit 1
}

# --- Missing arguments: never block a launch for that, fall back to a direct launch ---
if [[ -z "${game_id}" ]] || [[ -z "${version}" ]]; then
  zgu_log "launcher-orchestrator" "WARN" "reason=missing_arguments argv=$*"
  launch_lutris
fi

has_display=false
if [[ -n "${DISPLAY:-}" ]] || [[ -n "${WAYLAND_DISPLAY:-}" ]]; then
  has_display=true
fi

# --- No display possible (no GUI session, python3 or sqlite3 missing...): direct launch;
# no point querying the Lutris database for a screen that cannot be shown. ---
if [[ "${has_display}" = false ]] || ! command -v python3 >/dev/null 2>&1 || ! command -v sqlite3 >/dev/null 2>&1; then
  launch_lutris
fi

# --- Lutris database to query: same paths and convention ("version" = "flatpak" or
# "package", never "native"; see zgp-game-shortcutter.sh) as elsewhere in the project. No call
# to zgu_resolve_lutris_version: the version is already known (argument, fixed when the
# shortcut was created). ---
zgu_set_lutris_paths "$([[ "${version}" = "flatpak" ]] && echo flatpak || echo native)"

# --- Database not found: silent direct launch (just a log); a game launch must never fail
# for that. ---
if [[ ! -f "${lutris_db}" ]]; then
  zgu_log "launcher-orchestrator" "WARN" "game_id=${game_id} reason=db_not_found db=${lutris_db}"
  launch_lutris
fi

# --- slug + directory, by id: same query (columns) and "games_dir/slug" fallback as
# zgp-game-shortcutter.sh / zgp-game-installer.sh. game_id comes from Exec= (the .desktop
# itself, not free user input) but is interpolated as-is into the SQL as elsewhere in the
# project; filtered here to a pure integer as a precaution. ---
game_id="${game_id//[^0-9]/}"
if [[ -z "${game_id}" ]]; then
  zgu_log "launcher-orchestrator" "WARN" "reason=invalid_game_id"
  launch_lutris
fi

row=$(sqlite3 "${lutris_db}" "SELECT slug || char(31) || directory || char(31) || name || char(31) || COALESCE(configpath,'') FROM games WHERE id = ${game_id} AND runner = 'wine' LIMIT 1;" 2>/dev/null)

if [[ -z "${row}" ]]; then
  zgu_log "launcher-orchestrator" "WARN" "game_id=${game_id} reason=game_not_in_db"
  launch_lutris
fi

IFS=$'\x1f' read -r slug game_dir game_name configpath <<< "${row}"

if [[ -z "${slug}" ]]; then
  zgu_log "launcher-orchestrator" "WARN" "game_id=${game_id} reason=empty_slug_in_db"
  launch_lutris
fi

# Title shown at the bottom right of the loading screen (see zgu-launcher-screen.py): the
# game name by default; replaced by zgl-launcher-runtime.sh once the picker is resolved, ONLY
# if the game has several active Ludis Launcher entries. \n/\r are stripped: "name" comes from
# the Lutris database (possibly forged by a third party via a shared .zgp package) and the
# control file protocol is line-based.
title_text="${game_name//[$'\n\r']/}"

# games_dir (custom Games path of Lutris, else ~/Games) comes from zgu_set_lutris_paths; used only
# if "directory" is empty in the database.
[[ -z "${game_dir}" ]] && game_dir="${games_dir}/${slug}"

# --- FIXED-path control file (derived from game_dir, no random mktemp), so that
# zgl-launcher-runtime.sh (started separately, later, by Lutris) finds the same file with no
# data passed between the two scripts. sha256sum of game_dir rather than its basename: robust
# even if the game directory name does not match the slug (Lutris "directory" column). ---
ctrl_key=$(printf '%s' "${game_dir}" | sha256sum | cut -c1-24)
control_file="${TMPDIR:-/tmp}/lpm-launcher-ctrl-${ctrl_key}"

# --- Is the Ludis Launcher enabled for this game? Yes when the Lutris YAML runs lpm-launch.bat
# (game.exe) and ludis/launcher.yml exists. The old format (relay as Lutris prelaunch command,
# ludis <= 0.9.5) is converted here, at the first launch through an ludis shortcut:
# zgl-launcher-legacy.sh. If it cannot be (relay still referenced afterwards), the old
# mechanism keeps working untouched: "legacy_relay_present". ---
lutris_game_yml=""
[[ -n "${configpath}" ]] && lutris_game_yml="${lutris_config_dir}/${configpath}.yml"
# The Lutris YAML is READ AS YAML, never with grep: Lutris and PyYAML fold a long value onto
# two lines (a game folder with spaces in its name is enough: "exe: .../Zelda solarus" newline
# "    games/lpm-launch.bat"), and a line-based match then fails to see the launcher. The game
# silently launched with the lpm-launch.bat of the PREVIOUS launch: no picker, the last entry.
# Same test as zgp_launcher_is_active in zgl-launcher-manager.sh (what "ludis launcher status"
# and the GUI show). python3 is guaranteed here (checked above).
lutris_exe_is_launch_bat() {
  YML_PATH="$1" python3 -c '
import os, sys, yaml
try:
    with open(os.environ["YML_PATH"], "r") as f:
        data = yaml.safe_load(f) or {}
    exe = str((data.get("game") or {}).get("exe") or "")
    sys.exit(0 if os.path.basename(exe) == "lpm-launch.bat" else 1)
except Exception:
    sys.exit(1)
' 2>/dev/null
}

launcher_active=false
legacy_relay_present=false
if [[ -d "${game_dir}" ]] && [[ -f "$(zgu_ludis_find "${game_dir}" launcher)" ]] \
    && [[ -n "${lutris_game_yml}" ]] && [[ -f "${lutris_game_yml}" ]] \
    && lutris_exe_is_launch_bat "${lutris_game_yml}"; then
  launcher_active=true
  bash "${script_dir}/zgl-launcher-legacy.sh" "${lutris_game_yml}" "${game_dir}" >/dev/null 2>&1 || legacy_relay_present=true
fi

# --- Loading screen disabled for this game, or folder not found: no loading screen, but the
# Ludis Launcher still works (its own picker window, then lpm-launch.bat), then direct launch. ---
if [[ ! -d "${game_dir}" ]] || [[ -e "$(zgu_ludis_find "${game_dir}" no_loadingscreen)" ]]; then
  if [[ "${launcher_active}" = true ]] && [[ "${legacy_relay_present}" = false ]]; then
    bash "${script_dir}/zgl-launcher-runtime.sh" "${game_dir}"
  fi
  launch_lutris
fi

session_kind="x11"
if [[ "${XDG_SESSION_TYPE,,}" = "wayland" ]] || [[ -n "${WAYLAND_DISPLAY:-}" ]]; then
  session_kind="wayland"
fi

# --- Ludis Launcher (multi-entry picker): the YAML is read HERE, BEFORE the first background
# display, only to know whether a picker will be shown (the gamepad is not started yet). It
# decides the INITIAL background: if a picker follows, the splash must only appear AFTER the
# choice, never before only to vanish at once (flicker). ---
# Prefix made before the rename: its "lpm" folder becomes "ludis" (and the YAML paths follow).
zgu_ludis_adopt_old_dir "${game_dir}" "${lutris_game_yml}"
launcher_yml="$(zgu_ludis_find "${game_dir}" launcher)"
# NOT under /tmp: the /tmp of the Flatpak Lutris sandbox is invisible from the host, so
# zgl-launcher-runtime.sh (running INSIDE it for Flatpak Lutris) would never find a file
# written HERE on the host. "${game_dir}" is visible from both sides.
launcher_choice_file="$(zgu_ludis_path "${game_dir}" launcher_choice)"
rm -f "${launcher_choice_file}" "$(zgu_ludis_legacy_path "${game_dir}" launcher_choice)" 2>/dev/null
mkdir -p "$(dirname "${launcher_choice_file}")" 2>/dev/null

# Protocol of the picker embedded in the single window (see zgu-launcher-screen.py, file
# header): two fixed-path files derived from "control_file", never mixed into its 4 lines.
# Cleaned here as a precaution (leftover of an interrupted launch), before knowing whether
# a picker will be shown this time.
picker_request_file="${control_file}.picker-req"
picker_result_file="${control_file}.picker-res"
rm -f "${picker_request_file}" "${picker_result_file}" 2>/dev/null

picker_title="" picker_prompt=""
entry_labels=()
will_show_picker=false

if [[ "${launcher_active}" = true ]] && [[ "${has_display}" = true ]] \
    && command -v python3 >/dev/null 2>&1; then
  parsed=$(YML_PATH="${launcher_yml}" python3 -c '
import os, sys, yaml

try:
    with open(os.environ["YML_PATH"], "r") as f:
        data = yaml.safe_load(f) or {}
except Exception:
    sys.exit(1)

if not isinstance(data, dict):
    sys.exit(1)

title = str(data.get("title") or "")
prompt = str(data.get("prompt") or "")
entries = data.get("entries") or []
if not isinstance(entries, list):
    sys.exit(1)

print("TITLE\x1f" + title.replace("\x1f", " ").replace("\n", " "))
print("PROMPT\x1f" + prompt.replace("\x1f", " ").replace("\n", " "))
for e in entries:
    if not isinstance(e, dict):
        continue
    label = str(e.get("label") or "").replace("\x1f", " ").replace("\n", " ")
    if not label:
        continue
    print("ENTRY\x1f" + label)
' 2>/dev/null)

  while IFS=$'\x1f' read -r kind a; do
    case "${kind}" in
      TITLE) picker_title="${a}" ;;
      PROMPT) picker_prompt="${a}" ;;
      ENTRY)  entry_labels+=("${a}") ;;
    esac
  done <<< "${parsed}"

  [[ ${#entry_labels[@]} -gt 1 ]] && will_show_picker=true
fi

# --- Background: splash image if present, else plain black, EXCEPT when a picker will be
# shown: then NONE until the choice (see block above). ---
splash_image="$(zgu_ludis_find "${game_dir}" splash)/splash.png"
bg_state="NONE"
if [[ "${will_show_picker}" = false ]] && [[ -f "${splash_image}" ]]; then
  bg_state="${splash_image}"
fi

# --- Logo: next to the splash (same folder). Drawn DIRECTLY by zgu-launcher-screen.py in its
# own window (see its file header), no separate process: the picker never covers that area
# (top of the screen, above its always-centered frame), so no "always on top" window is
# needed. If absent, zgu-launcher-screen.py shows the title there instead; passed even if
# missing, the existence check is done on the Python side.
logo_image="$(zgu_ludis_find "${game_dir}" splash)/logo.png"

# Known in advance (see YAML block above, "will_show_picker"): "1" if this game has a single
# entry (or none), so no label is ever shown on the loading screen; see <no_label> in the
# header of zgu-launcher-screen.py, which then recenters the banner instead of reserving an
# empty band.
no_label_flag="1"
[[ "${will_show_picker}" = true ]] && no_label_flag="0"

# Also known in advance: "1" if this game will show a banner (splash.png present); see
# <has_banner> in the header of zgu-launcher-screen.py. Only used together with
# no_label_flag="1" above (while a picker remains possible the layout never changes).
has_banner_flag="0"
[[ -f "${splash_image}" ]] && has_banner_flag="1"

{
  printf '%s\n' "${bg_state}"
  printf '%s\n' "IND_SHOW"
  printf '%s\n' "${title_text}"
  printf '%s\n' ""
} > "${control_file}" 2>/dev/null

indicator_text="$(t launcher.loading_text)"

blackscreen_pid=""

# zgu-launcher-screen.py reads the gamepad itself via SDL2, in its own process: no separate bridge
# is started here (a bridge injecting keys through xdotool/ydotool into the focused window depended
# on the window manager: focus stealing prevention on X11, no portable equivalent on Wayland).
# Forced foreground recovery by the loading screen (on_active_changed in zgu-launcher-screen.py):
# DISABLED by default, because a fullscreen Wine game that loses focus gets iconified, so forcing
# focus back minimized it. A game whose window is recreated several times at startup (e.g.
# Momodora) can enable it with an empty "ludis/settings/keep-focus" file (never created
# automatically, like "ludis/settings/no-loadingscreen").
# WM_CLASS of the game = StartupWMClass of the .desktop generated by ludis (zgu_write_game_shortcut):
# the loading window reuses it to group under the game's panel icon. Empty if the menu shortcut
# does not exist.
screen_wm_class=""
shortcut_file="${HOME}/.local/share/applications/net.lutris.${slug}.desktop"
if [[ -f "${shortcut_file}" ]]; then
  screen_wm_class=$(sed -n 's/^StartupWMClass=//p' "${shortcut_file}" | head -n1)
  screen_wm_class="${screen_wm_class//[$'\n\r\t']/}"
fi
keep_focus_env=0
[[ -e "$(zgu_ludis_find "${game_dir}" keep_focus)" ]] && keep_focus_env=1
# Per-game message shown at the bottom center of the loading screen (explains a long loading).
# VISIBLE file at the prefix root, created empty if missing, never overwritten; an empty file
# shows nothing. One line of the file = one message (the screen shows one at a time, wraps a long
# one, and alternates when there are several); 1200 characters at most, CR and tabs become spaces.
loading_message_file="$(zgu_ludis_find "${game_dir}" loading_message)"
if [[ ! -e "${loading_message_file}" ]]; then
  mkdir -p "$(dirname "${loading_message_file}")" 2>/dev/null
  : > "${loading_message_file}" 2>/dev/null
fi
loading_message=$(head -c 1200 "${loading_message_file}" 2>/dev/null | tr '\r\t' '  ')
LUDIS_PREFIX_DIR="${game_dir}" LUDIS_LOADING_MESSAGE="${loading_message}" LUDIS_HELP_ALTTAB="$(t launcher.help_alttab)" LUDIS_HELP_QUIT="$(t launcher.help_quit)" LUDIS_WM_CLASS="${screen_wm_class}" LUDIS_WINDOW_TITLE="${title_text}" LUDIS_KEEP_FOCUS="${keep_focus_env}" python3 "${script_dir}/zgu-launcher-screen.py" "${control_file}" "${indicator_text}" "${logo_image}" "${no_label_flag}" "${has_banner_flag}" >/dev/null 2>&1 &
blackscreen_pid=$!
disown "${blackscreen_pid}" 2>/dev/null

sleep 0.3  # let the background render before Lutris (or the picker) does anything

zgu_log "launcher-orchestrator" "OK" "slug=${slug} action=background_started ctrl=${control_file}"

# --- Ludis Launcher (multi-entry picker): resolved HERE, on the host, NOT by
# zgl-launcher-runtime.sh (started later by Lutris, inside its sandbox for Flatpak Lutris, where
# neither gamepad nor mouse reliably reached Zenity). The choice is passed to the runtime through
# a fixed-path file derived from game_dir, like the control file; the runtime only reads it and
# writes lpm-launch.bat (run by THIS script; its own picker is used only when the loading screen
# is disabled).
#
# The YAML was already read above (entry_labels/picker_title/picker_prompt/will_show_picker).
# The picker is INTEGRATED in the single window launched above (zgu-launcher-screen.py,
# "Gtk.Overlay"): no second window, so no "always on top" problem (GTK4 removed
# "set_keep_above"). The request goes through "picker_request_file", the answer comes back through
# "picker_result_file"; their format is in the header of zgu-launcher-screen.py.
if [[ "${will_show_picker}" = true ]]; then
    # IND_HIDE: the loading indicator disappears during the choice. Background is already "NONE"
    # since the first display (see above), only the indicator changes. Title unchanged.
    {
      printf '%s\n' "NONE"
      printf '%s\n' "IND_HIDE"
      printf '%s\n' "${title_text}"
      printf '%s\n' ""
    } > "${control_file}" 2>/dev/null

    {
      printf '%s\n' "${picker_title}"
      printf '%s\n' "${picker_prompt}"
      printf '%s\n' "$(t launcher.picker_validate_button)"
      printf '%s\n' "$(t launcher.picker_cancel_button)"
      printf '%s\n' "$(t launcher.picker_validate_button)"
      printf '%s\n' "$(t launcher.picker_cancel_button)"
      for entry in "${entry_labels[@]}"; do
        printf '%s\n' "${entry}"
      done
    } > "${picker_request_file}" 2>/dev/null

    # Wait for the result by polling, like the control file itself, with no time limit (the
    # user may take as long as needed). Also exits if the window ended meanwhile (crash,
    # "kill -9"...), otherwise the loop would wait forever for a file that never comes.
    picker_rc=1
    selection=""
    while true; do
      if [[ -f "${picker_result_file}" ]]; then
        mapfile -t _picker_result_lines < "${picker_result_file}" 2>/dev/null
        rm -f "${picker_result_file}" 2>/dev/null
        if [[ "${_picker_result_lines[0]:-}" = "OK" ]]; then
          selection="${_picker_result_lines[1]:-}"
          picker_rc=0
        fi
        break
      fi
      if [[ -n "${blackscreen_pid}" ]] && ! kill -0 "${blackscreen_pid}" 2>/dev/null; then
        zgu_log "launcher-orchestrator" "WARN" "slug=${slug} reason=window_closed_during_picker"
        break
      fi
      sleep 0.1
    done
    rm -f "${picker_request_file}" 2>/dev/null

    if [[ "${picker_rc}" -ne 0 ]] || [[ -z "${selection}" ]]; then
      # Cancelled (Cancel button, Escape, B button, all treated alike, see
      # zgu-launcher-screen.py) OR error/window gone: the flow is stopped ENTIRELY, the game is NOT
      # launched ("cancel" must mean cancel).
      rm -f "${launcher_choice_file}" 2>/dev/null
      zgu_log "launcher-orchestrator" "INFO" "slug=${slug} reason=picker_cancelled action=full_stop"
      echo "STOP" > "${control_file}" 2>/dev/null
      sleep 0.3
      [[ -n "${blackscreen_pid}" ]] && kill "${blackscreen_pid}" 2>/dev/null
      rm -f "${control_file}" 2>/dev/null
      exit 0
    fi

    # Written as soon as a choice is validated: its mere PRESENCE tells zgl-launcher-runtime.sh
    # that THIS script ran and decided; absence means fallback on its own picker.
    printf '%s' "${selection}" > "${launcher_choice_file}" 2>/dev/null

    # Background AFTER the choice: the splash (if any) only appears from now on, never before
    # the picker (bg_state was "NONE" until here).
    post_choice_bg="NONE"
    [[ -f "${splash_image}" ]] && post_choice_bg="${splash_image}"

    # Title UNCHANGED (still the game name, see zgu-launcher-screen.py): the chosen label is
    # added on its own line, never in its place. EXCEPT when the label is exactly the game name
    # (strict comparison): then no subtitle, the screen looks like one of a game without
    # Ludis Launcher.
    chosen_label_line="${selection//[$'\n\r']/}"
    [[ "${chosen_label_line}" = "${title_text}" ]] && chosen_label_line=""
    {
      printf '%s\n' "${post_choice_bg}"
      printf '%s\n' "IND_SHOW"
      printf '%s\n' "${title_text}"
      printf '%s\n' "${chosen_label_line}"
    } > "${control_file}" 2>/dev/null
    zgu_log "launcher-orchestrator" "OK" "slug=${slug} action=picker_choice entry=${selection}"
fi

# --- lpm-launch.bat: written NOW, on the host, with the entry just chosen (or the only entry),
# before Lutris starts. Unless the old relay is still active (legacy_relay_present): then it
# writes the .bat itself from the choice file, as before. ---
if [[ "${launcher_active}" = true ]] && [[ "${legacy_relay_present}" = false ]]; then
  bash "${script_dir}/zgl-launcher-runtime.sh" "${game_dir}"
fi

# --- Universal game window detection (WIN_CreateWindowEx via WINEDEBUG) ---
#
# A signal independent of the display server (X11/Wayland), the runner (Wine-GE, Proton/umu, plain
# Wine) and the graphics API: Wine traces the creation of EVERY Win32 window via
# WIN_CreateWindowEx. The real game window is told apart from internal ones (Shell_TrayWnd,
# WineDdeServerName, SDLHelperWindowInputMsgWindow...) by its size; see the generated relay below
# for the trace format.
#
# Lutris' "prefix_command" (YAML key "system: prefix_command") is NOT interpreted by a shell, so a
# REAL script is needed to set WINEDEBUG="+win" and redirect the trace to a file. It is patched at
# EVERY launch (idempotent, chained only once); a "Command prefix" of the user (e.g. gamemoderun)
# is always kept.
#
# NEVER a machine-fixed path (no "${script_dir}/..." under /usr/lib/ludis, no /tmp): with Flatpak
# Lutris, /usr is the runtime's, not the host's, so Lutris' "exec" failed, and a trace file written
# in the sandbox's PRIVATE /tmp is never seen from the host (same trap as "launcher_choice_file"
# above). A "ludis ..." command would not work either, since ludis is not in the sandbox PATH.
# So the relay is GENERATED under "${game_dir}/ludis/scripts" (visible on both sides of the sandbox),
# holds all the logic in a few lines, and is portable in a .zgp export; it is regenerated at every
# launch anyway.
winetrace_scripts_dir="$(zgu_ludis_path "${game_dir}" scripts)"
winetrace_wrapper="${winetrace_scripts_dir}/lpm-winetrace.sh"
trace_file="${winetrace_scripts_dir}/lpm-winetrace.log"
rm -f "${trace_file}" 2>/dev/null
# Old layout (scripts/ at the prefix root): its relay and trace are replaced by the ones in ludis/scripts.
rm -f "$(zgu_ludis_legacy_path "${game_dir}" scripts)/lpm-winetrace.sh" "$(zgu_ludis_legacy_path "${game_dir}" scripts)/lpm-winetrace.log" 2>/dev/null
rmdir "$(zgu_ludis_legacy_path "${game_dir}" scripts)" 2>/dev/null

use_winetrace=false

if [[ -n "${configpath}" ]] && command -v python3 >/dev/null 2>&1 \
    && python3 -c "import yaml" >/dev/null 2>&1; then
  # "scripts/" may not exist yet (no game necessarily enables the Ludis Launcher, the only other
  # place creating it; see zgl-launcher-manager.sh): create it here if needed.
  mkdir -p "${winetrace_scripts_dir}" 2>/dev/null

  cat > "${winetrace_wrapper}" <<'WRAPPER_EOF'
#!/bin/bash
# Relay generated by ludis (universal game-window detection) -- do not edit by hand, it is
# rewritten on every launch.
#
# Usage: lpm-winetrace.sh <trace_file> <real_command...>
#
# Lutris does not interpret "prefix_command" with a shell (it splits it into words and runs the
# resulting argv directly), so this real bash script does the redirection instead: it sets
# WINEDEBUG="+win", then execs the real command (everything after the first argument) while
# filtering its stderr live into <trace_file>, keeping only lines containing "WIN_CreateWindowEx".
set -u
trace_file="${1:-}"
shift || true
if [[ -z "${trace_file}" ]] || [[ $# -eq 0 ]]; then
  exec "$@"
fi
export WINEDEBUG="+win"
exec "$@" 2> >(grep --line-buffered "WIN_CreateWindowEx" >> "${trace_file}")
WRAPPER_EOF
  chmod +x "${winetrace_wrapper}" 2>/dev/null

  if [[ -x "${winetrace_wrapper}" ]]; then
    yml_path="${lutris_config_dir}/${configpath}.yml"
    if [[ -f "${yml_path}" ]]; then
      patch_result=$(YML_PATH="${yml_path}" WRAPPER="${winetrace_wrapper}" TRACE_FILE="${trace_file}" python3 -c '
import os
import shutil
import sys

import yaml

yml_path = os.environ["YML_PATH"]
wrapper_cmd = os.environ["WRAPPER"]
trace_file_path = os.environ["TRACE_FILE"]
wanted_prefix = f"{wrapper_cmd} {trace_file_path}"

try:
    with open(yml_path, "r") as f:
        data = yaml.safe_load(f)
except Exception:
    sys.exit(1)

if not isinstance(data, dict):
    sys.exit(1)

system_cfg = data.get("system")
if not isinstance(system_cfg, dict):
    system_cfg = {}
    data["system"] = system_cfg

# Never overwrite a user "Command prefix": if our wrapper is already there (previous launch),
# strip the user-specific tail and rebuild it behind the up-to-date wrapper (the trace path
# is normally identical, so this usually changes nothing).
current = str(system_cfg.get("prefix_command") or "")
import re

if current.startswith(wanted_prefix):
    user_tail = current[len(wanted_prefix):].lstrip()
else:
    # Wrapper of the old layout (<prefix>/scripts/...): replaced, never stacked.
    user_tail = re.sub(r"^\s*\S*/scripts/lpm-winetrace\.sh\s+\S*lpm-winetrace\.log\s*", "", current)
new_value = wanted_prefix if not user_tail else f"{wanted_prefix} {user_tail}"

if new_value == current:
    print("OK")
    sys.exit(0)

system_cfg["prefix_command"] = new_value

try:
    shutil.copy2(yml_path, yml_path + ".lpm-bak")
    with open(yml_path, "w") as f:
        yaml.dump(data, f, sort_keys=False)
except Exception:
    sys.exit(1)

try:
    os.remove(yml_path + ".lpm-bak")
except OSError:
    pass

print("OK")
' 2>/dev/null)

      [[ "${patch_result}" = "OK" ]] && use_winetrace=true
    fi
  fi
fi

if [[ "${use_winetrace}" = false ]]; then
  zgu_log "launcher-orchestrator" "WARN" "slug=${slug} reason=winetrace_unavailable_fallback_xdotool"
fi

# --- Detached watcher: game window detection + minimum display time, then full cleanup.
# Runs independently: THIS script "exec"s right after and disappears (replaced by lutris),
# the watcher keeps running in the background. ---
MIN_DISPLAY_MS=1000

# Decides whether ONE line of the Wine window trace ("WIN_CreateWindowEx ...") is the creation of
# the GAME window (return 0) or of an internal one (return 1). A function so that
# tests/cli_smoke.sh can replay real traces through it.
#
# 1. Wine's own windows are ignored by class name whatever their size: recent Wine creates its
#    taskbar "Shell_TrayWnd" at startup with a title bar and a real size (166x52 with GE-Proton),
#    which closed the loading screen seconds too early (Bloodborne).
# 2. Size criterion: width and height above WIN_SIZE_THRESHOLD.
# 3. Title-bar criterion: some games create their real window very small and resize it later
#    (e.g. Kirby Soft And Wet, 106x132). An application window has a title bar (WS_CAPTION,
#    0x00C00000, in "style="), unlike Wine/SDL technical windows, so it is accepted from
#    WIN_CAPTION_MIN_SIZE x WIN_CAPTION_MIN_SIZE. The minimum must stay at 32: Bloodborne first
#    runs a launcher whose hidden SDL helper window ("SDL_app", 7x33) comes BEFORE the real game
#    window, and a smaller minimum would close the loading screen too early.
# The "x" between two numbers followed by "parent=" occurs only in that place of the format
# (confirmed on real captures), so a hexadecimal field (ex=, style=, inst=) never matches.
WIN_SIZE_THRESHOLD=200
WIN_CAPTION_MIN_SIZE=32
WIN_CAPTION_STYLE_MASK=$(( 0x00C00000 ))
WIN_IGNORED_CLASSES=(Shell_TrayWnd IPTip_Main_Window WineAppBar SDLHelperWindowInputMsgWindow XaliaOverlayBox)

# Per-game ignored windows: VISIBLE file (no leading dot) at the prefix root, created empty if
# missing, never overwritten, so user-edited content survives (same convention as
# lpm-max-wait-s / lpm-extra-loading-ms below). One word per line, matched case-sensitively
# anywhere in the trace line (window title OR class), so a helper program started before the
# game with a real window (e.g. "bbbridge", the Bloodborne online bridge, which ignores a
# hidden start) is never taken for the game window. Empty lines and "#" comments are skipped.
WIN_IGNORED_WORDS=()
ignored_windows_file="${game_dir:+$(zgu_ludis_find "${game_dir}" ignore_windows)}"
if [[ -n "${ignored_windows_file}" ]] && [[ ! -e "${ignored_windows_file}" ]]; then
  mkdir -p "$(dirname "${ignored_windows_file}")" 2>/dev/null
  : > "${ignored_windows_file}" 2>/dev/null
fi
if [[ -n "${ignored_windows_file}" ]] && [[ -r "${ignored_windows_file}" ]]; then
  while IFS= read -r ignored_word || [[ -n "${ignored_word}" ]]; do
    ignored_word="${ignored_word//$'\r'/}"
    ignored_word="${ignored_word#"${ignored_word%%[![:space:]]*}"}"
    ignored_word="${ignored_word%"${ignored_word##*[![:space:]]}"}"
    [[ -z "${ignored_word}" ]] || [[ "${ignored_word}" == \#* ]] && continue
    WIN_IGNORED_WORDS+=("${ignored_word}")
  done < "${ignored_windows_file}"
fi

zgl_trace_line_is_game_window() {
  local line="$1" ignored_class ignored_word win_w win_h
  for ignored_class in "${WIN_IGNORED_CLASSES[@]}"; do
    [[ "${line}" == *"->L\"${ignored_class}\""* ]] && return 1
  done
  for ignored_word in "${WIN_IGNORED_WORDS[@]}"; do
    [[ "${line}" == *"${ignored_word}"* ]] && return 1
  done
  [[ "${line}" =~ ([0-9]+)x([0-9]+)[[:space:]]+parent= ]] || return 1
  win_w="${BASH_REMATCH[1]}"
  win_h="${BASH_REMATCH[2]}"
  if [[ "${win_w}" -gt "${WIN_SIZE_THRESHOLD}" ]] && [[ "${win_h}" -gt "${WIN_SIZE_THRESHOLD}" ]]; then
    return 0
  fi
  if [[ "${win_w}" -ge "${WIN_CAPTION_MIN_SIZE}" ]] && [[ "${win_h}" -ge "${WIN_CAPTION_MIN_SIZE}" ]] \
     && [[ "${line}" =~ style=([0-9A-Fa-f]{1,8})[[:space:]] ]] \
     && [[ $(( 0x${BASH_REMATCH[1]} & WIN_CAPTION_STYLE_MASK )) -eq "${WIN_CAPTION_STYLE_MASK}" ]]; then
    return 0
  fi
  return 1
}

# Safety margin AFTER the game window detection (or after the fixed wait on Wayland): the
# new window may not be fully initialized (e.g. a frame generation tool like LSFG can cause a
# small hitch right after it appears). Without it the background vanished exactly then.
POST_WINDOW_GRACE_MS=1000

(
  start_ms=$(date +%s%3N 2>/dev/null || echo 0)
  # Maximum wait for the game window: VISIBLE file at the prefix root, created with 60 if
  # missing, never overwritten, so a user-edited value survives. For a game whose window takes
  # minutes to appear (heavy mods...). Only whole seconds between 5 and 3600 are accepted.
  max_wait_file="$(zgu_ludis_find "${game_dir}" max_wait)"
  if [[ ! -f "${max_wait_file}" ]]; then
    mkdir -p "$(dirname "${max_wait_file}")" 2>/dev/null
    printf '60' > "${max_wait_file}" 2>/dev/null
  fi
  max_wait_s=$(tr -cd '0-9' < "${max_wait_file}" 2>/dev/null)
  [[ -n "${max_wait_s}" ]] && max_wait_s=$(( 10#${max_wait_s} ))  # "060" is not octal
  if [[ -z "${max_wait_s}" ]] || [[ "${max_wait_s}" -lt 5 ]] || [[ "${max_wait_s}" -gt 3600 ]]; then
    max_wait_s=60
  fi
  waited=0
  window_detected=""

  # Extra per-game margin: VISIBLE file (no leading dot) at the prefix root, created with "0"
  # if missing, never overwritten, so a user-edited value survives all later launches. Added to
  # POST_WINDOW_GRACE_MS above; useful for a game whose window appears before it is really
  # playable (e.g. shader compilation right after the window appears).
  extra_ms_file="$(zgu_ludis_find "${game_dir}" extra_loading)"
  if [[ ! -f "${extra_ms_file}" ]]; then
    mkdir -p "$(dirname "${extra_ms_file}")" 2>/dev/null
    printf '0' > "${extra_ms_file}" 2>/dev/null
  fi
  extra_ms=$(tr -cd '0-9' < "${extra_ms_file}" 2>/dev/null)
  [[ -z "${extra_ms}" ]] && extra_ms=0

  if [[ "${use_winetrace}" = true ]]; then
    # Universal detection (X11/Wayland alike, any runner): re-reads the trace file (already
    # filtered live by the lpm-winetrace.sh relay, so every line contains "WIN_CreateWindowEx")
    # looking for the creation of the game window (rules in zgl_trace_line_is_game_window above).
    while [[ "${waited}" -lt "${max_wait_s}" ]]; do
      if [[ -s "${trace_file}" ]]; then
        while IFS= read -r trace_line; do
          if zgl_trace_line_is_game_window "${trace_line}"; then
            window_detected="1"
            break
          fi
        done < "${trace_file}"
      fi
      [[ -n "${window_detected}" ]] && break
      sleep 1
      waited=$(( waited + 1 ))
    done
  elif [[ "${session_kind}" = "x11" ]] && command -v xdotool >/dev/null 2>&1; then
    before_windows=$(xdotool search --onlyvisible "" 2>/dev/null | sort)
    while [[ "${waited}" -lt "${max_wait_s}" ]]; do
      sleep 1
      waited=$(( waited + 1 ))
      after_windows=$(xdotool search --onlyvisible "" 2>/dev/null | sort)
      new_windows=$(comm -13 <(echo "${before_windows}") <(echo "${after_windows}"))
      if [[ -n "${new_windows}" ]]; then
        window_detected="1"
        break
      fi
    done
  elif [[ "${session_kind}" = "x11" ]]; then
    # xdotool missing on an X11 session: degrades to the Wayland fixed wait, but LOGGED (same
    # symptoms as Wayland: always exactly 12s, even for a game starting in 2s). "ludis check" also
    # recommends installing xdotool on an X11 session; see zgc-dependency-checker.sh.
    zgu_log "launcher-orchestrator" "WARN" "slug=${slug} reason=xdotool_missing_fixed_wait_fallback"
    sleep 12
  else
    # Wayland: xdotool cannot list/detect windows of other applications, so a reasonable fixed
    # wait. This fallback should only happen without PyYAML/configpath (see "use_winetrace"
    # above): universal detection works on both Wayland and X11.
    sleep 12
  fi

  # Post-detection safety margin (see POST_WINDOW_GRACE_MS above) + extra per-game margin (see
  # extra_ms above). Applies in all cases (window detected via trace/xdotool, or fixed wait
  # elapsed).
  total_grace_ms=$(( POST_WINDOW_GRACE_MS + extra_ms ))
  sleep "$(awk -v ms="${total_grace_ms}" 'BEGIN { printf "%.3f", ms / 1000 }')"

  # Minimum duration: avoids a flash if the game starts abnormally fast.
  if [[ "${start_ms}" != "0" ]]; then
    now_ms=$(date +%s%3N 2>/dev/null || echo 0)
    elapsed_ms=$(( now_ms - start_ms ))
    if [[ "${elapsed_ms}" -lt "${MIN_DISPLAY_MS}" ]]; then
      remaining_ms=$(( MIN_DISPLAY_MS - elapsed_ms ))
      sleep "$(awk -v ms="${remaining_ms}" 'BEGIN { printf "%.3f", ms / 1000 }')"
    fi
  fi

  # --- Timeout without any window appearing (detectable when universal detection is active,
  # "use_winetrace", or as fallback on X11 with xdotool; no reliable signal otherwise, so never
  # a false warning there): instead of vanishing silently as if all went well, shows a warning
  # a few seconds before closing, reusing the "title" line (see zgu-launcher-screen.py). The
  # "loading"/spinner indicator is hidden at the same time. ---
  if { [[ "${use_winetrace}" = true ]] || { [[ "${session_kind}" = "x11" ]] && command -v xdotool >/dev/null 2>&1; }; } \
      && [[ -z "${window_detected}" ]]; then
    zgu_log "launcher-orchestrator" "WARN" "slug=${slug} reason=no_window_detected_after_delay delay_s=${max_wait_s}"
    # Diagnostic kept for "why was no window recognised?": the windows Wine created (a copy of the
    # trace, last 200 lines) and whether the game's wineserver is still running (= still starting).
    if [[ -s "${trace_file}" ]]; then
      tail -n 200 "${trace_file}" > "${ZGU_LOG_DIR}/last-window-trace.log" 2>/dev/null
    else
      : > "${ZGU_LOG_DIR}/last-window-trace.log" 2>/dev/null
    fi
    zgu_log "launcher-orchestrator" "INFO" "slug=${slug} reason=no_window_trace trace_lines=$(wc -l < "${ZGU_LOG_DIR}/last-window-trace.log" 2>/dev/null || echo 0) file=${ZGU_LOG_DIR}/last-window-trace.log"
    {
      printf '%s\n' "${bg_state}"
      printf '%s\n' "IND_HIDE"
      printf '%s\n' "$(t launcher.launch_timeout_warning)"
    } > "${control_file}" 2>/dev/null
    sleep 4
  fi

  echo "STOP" > "${control_file}" 2>/dev/null
  sleep 0.3
  [[ -n "${blackscreen_pid}" ]] && kill "${blackscreen_pid}" 2>/dev/null
  rm -f "${control_file}" 2>/dev/null
  rm -f "${trace_file}" 2>/dev/null
) </dev/null >/dev/null 2>&1 &
disown $! 2>/dev/null

# --- Gamepad "quit game" combo (SIGTERM to the prefix Wine processes); see
# zgu-gamepad-exit-watcher.py for details (why a script apart from the gamepad bridge, why no
# grab(), why no safety net). Started HERE, just before handing over to Lutris (the "exec"
# below never returns, so the orchestrator loses track of the game: the watcher must already
# run before that point).
#
# "pkill" before restarting: this script stops by itself once the combo is used, but NOT if
# the game is quit another way (undetectable from here), so without this cleanup an orphan
# instance from a previous session would stay active next to the new one. Assumes one game
# at a time (consistent with the rest of ludis).
# --- FPS overlay (MangoHud) switchable from the Ludis menu: loaded now but HIDDEN, only when it is
# wanted for this game (per-game setting, else global), MangoHud is installed and the Lutris option
# "Enable MangoHud" is not already on (that one shows it all the time). Environment of THIS launch
# only: nothing is written to the prefix or to Lutris. The menu shows its entry only when
# "overlay-armed" names this prefix. ---
overlay_armed_file="${XDG_RUNTIME_DIR:-/tmp}/ludis-overlay-armed-$(id -u)"
rm -f "${overlay_armed_file}" "${XDG_RUNTIME_DIR:-/tmp}/ludis-overlay-visible-$(id -u)" 2>/dev/null
overlay_reason=""
overlay_arm_pending=false   # "available": the menu shows the entry; "armed": MangoHud is also loaded now
overlay_state_line=""
if [[ "${has_display}" != true ]]; then
  overlay_reason="no_display"
elif grep -Eq '^[[:space:]]+mangohud:[[:space:]]*true' "${lutris_game_yml:-/nonexistent}" 2>/dev/null; then
  overlay_reason="lutris_mangohud_already_on (always visible, nothing armed)"
else
  overlay_found=false
  if [[ "${version}" = "flatpak" ]]; then
    flatpak list --runtime --columns=application 2>/dev/null | grep -qi 'MangoHud' && overlay_found=true
  else
    command -v mangohud >/dev/null 2>&1 && overlay_found=true
  fi
  if [[ "${overlay_found}" != true ]]; then
    overlay_reason="mangohud_not_found (lutris=${version})"
  else
    overlay_arm_pending=true
    overlay_state_line="available"
    if zgu_overlay_fps_wanted "${game_dir}"; then
      # read_cfg: keep the user's own MangoHud.conf look; no_display: hidden at start; the toggle key
      # is set explicitly because the menu sends it.
      overlay_config="read_cfg,no_display,toggle_hud=Shift_R+F12"
      export MANGOHUD=1 MANGOHUD_CONFIG="${overlay_config}"
      overlay_flatpak_env=("--env=MANGOHUD=1" "--env=MANGOHUD_CONFIG=${overlay_config}")
      overlay_state_line="armed"
      zgu_log "launcher-orchestrator" "OK" "slug=${slug} overlay=armed hidden config=${overlay_config} lutris=${version}"
    else
      overlay_reason="not_loaded game=$(zgu_overlay_fps_pergame "${game_dir}") global=$(zgu_overlay_fps_global) (entry available in the menu)"
    fi
  fi
fi
[[ -n "${overlay_reason}" ]] && zgu_log "launcher-orchestrator" "INFO" "slug=${slug} overlay=not_armed reason=${overlay_reason}"

if [[ "${has_display}" = true ]] && command -v python3 >/dev/null 2>&1; then
  pkill -f "zgu-gamepad-exit-watcher.py" 2>/dev/null
  # The previous watcher (still running when the game is relaunched at once) removes the
  # "overlay-armed" file as it stops: wait for it to be gone, THEN write ours.
  for _ in $(seq 1 30); do pgrep -f "zgu-gamepad-exit-watcher.py" >/dev/null 2>&1 || break; sleep 0.1; done
  [[ "${overlay_arm_pending}" = true ]] && printf '%s\n%s\n' "${game_dir}" "${overlay_state_line}" > "${overlay_armed_file}" 2>/dev/null
  LUDIS_MENU_TITLE="$(t launcher.menu_title)" LUDIS_MENU_HINT="$(t launcher.menu_hint)" \
    LUDIS_MENU_WINDOW="$(t launcher.menu_window)" LUDIS_MENU_ALTENTER="$(t launcher.menu_altenter)" \
    LUDIS_MENU_ESCAPE="$(t launcher.menu_escape)" LUDIS_MENU_QUIT="$(t launcher.menu_quit)" LUDIS_MENU_FORCE="$(t launcher.menu_force)" LUDIS_MENU_ALTF4_CONFIRM="$(t launcher.menu_altf4_confirm)" \
    LUDIS_MENU_KEYBOARD="$(t launcher.menu_keyboard)" LUDIS_MENU_MOUSE="$(t launcher.menu_mouse)" LUDIS_MENU_OVERLAY="$(t launcher.menu_overlay)" LUDIS_MENU_OVERLAY_OFF="$(t launcher.menu_overlay_off)" LUDIS_MENU_OVERLAY_HIDDEN="$(t launcher.menu_overlay_hidden)" LUDIS_MENU_OVERLAY_ON="$(t launcher.menu_overlay_on)" LUDIS_MENU_OVERLAY_LATER="$(t launcher.menu_overlay_later)" LUDIS_MENU_VOLUME="$(t launcher.menu_volume)" LUDIS_MENU_MUTE="$(t launcher.menu_mute)" \
    LUDIS_KB_HINT="$(t launcher.kb_hint)" LUDIS_KB_HINT_KEYS="$(t launcher.kb_hint_keys)" LUDIS_KB_NOLAYOUT="$(t launcher.kb_nolayout)" \
    LUDIS_MENU_QUIT_CONFIRM="$(t launcher.menu_quit_confirm)" LUDIS_MENU_QUIT_CANCEL="$(t launcher.menu_quit_cancel)" \
    python3 "${script_dir}/zgu-gamepad-exit-watcher.py" "${session_kind}" "${game_dir}" >/dev/null 2>&1 &
  disown $! 2>/dev/null

  # --- Gamepad "switch window" combo (Alt+Tab); see zgu-gamepad-alttab-watcher.py. Unlike the
  # quit combo above, this one runs during the WHOLE game session (not one-shot) and stops by
  # itself when the game ends; same "pkill" before restart in case an instance is left over.
  pkill -f "zgu-gamepad-alttab-watcher.py" 2>/dev/null
  python3 "${script_dir}/zgu-gamepad-alttab-watcher.py" "${session_kind}" "${game_dir}" >/dev/null 2>&1 &
  disown $! 2>/dev/null
fi

launch_lutris

#!/bin/bash

# --- lpm killwine: immediately kills every running Wine/Winetricks/umu-run/Proton process,
# whatever the game or prefix (a "panic" button for a stuck/crashed process) ---
#
# Unlike "lpm tools <game> <action>" (which targets ONE game with the wine binary resolved from its
# config), this command is deliberately broad: any wine/wine64/wine-preloader/wine64-preloader/
# wineserver/winetricks/umu-run process is killed, wherever it comes from.
#
# EXCEPTION: Proton. "proton" is too generic to match blindly on the command line (it would also
# kill ProtonVPN, ProtonMail Bridge, Proton Pass...). So "proton" is only killed if its executable
# path is under the Lutris runners folder (Lutris installs Wine AND Proton there), which catches
# any Proton launched by/for Lutris (via umu-run) without touching another vendor's Proton.
#
# Implemented by reading /proc/<pid>/cmdline directly (rather than a plain "pkill -x"), for two reasons:
#   1. "pkill -x" compares the kernel "comm" name, TRUNCATED to 15 characters -- "wine64-preloader"
#      is 16 characters and would NEVER match with -x.
#   2. Safety: each PID found is compared to $$ (this script) and $PPID (its parent, e.g. the bash of
#      bin/lpm) before being killed, in addition to anchoring the pattern on "/" and a separator --
#      extra caution for a destructive, irreversible action (-9, no confirmation afterwards).

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./zgl-lang-loader.sh
source "${script_dir}/zgl-lang-loader.sh"
# shellcheck source=./zgu-cli-utils.sh
source "${script_dir}/zgu-cli-utils.sh"

# $1 = mode (always "cli"; kept for positional consistency with other lib/ scripts, not read here)
shift || true
confirm_flag="${1:-}"

if ! command -v pgrep >/dev/null 2>&1; then
  zgu_cli_error "$(t wine_killer.pgrep_missing)"
  exit 1
fi

# --- Confirmation (destructive, irreversible: stops every running Wine game, unsaved progress is lost) ---
if [[ "${confirm_flag}" != "yes" ]]; then
  t wine_killer.confirm_cli_header
  read -r -p "$(t wine_killer.confirm_cli_prompt)" response
  case "${response}" in
    [oOyY]) : ;;
    *)
      t wine_killer.cancelled_cli
      exit 0
      ;;
  esac
fi

# --- Lutris runner paths (Flatpak AND native package are always checked, regardless of the "active"
# version -- a process left by the other install method must still be detected). ---
lutris_flatpak_runner_dir="${HOME}/.var/app/net.lutris.Lutris/data/lutris/runners/wine"
lutris_package_runner_dir="${HOME}/.local/share/lutris/runners/wine"

self_pid="$$"
parent_pid="${PPID}"

# zgc_kill_matching <extended_regex_pattern>
# Kills (-9) every process whose full command line (/proc/<pid>/cmdline) matches the pattern, except
# this script and its direct parent. Prints the number of processes actually killed on stdout.
zgc_kill_matching() {
  local pattern="$1"
  local pid killed=0
  while IFS= read -r pid; do
    [[ -z "${pid}" ]] && continue
    [[ "${pid}" = "${self_pid}" ]] && continue
    [[ "${pid}" = "${parent_pid}" ]] && continue
    if kill -9 "${pid}" 2>/dev/null; then
      killed=$((killed + 1))
    fi
  done < <(pgrep -f -- "${pattern}" 2>/dev/null)
  echo "${killed}"
}

total_killed=0

# wine/wine64/wine-preloader/wine64-preloader/wineserver/winetricks/umu-run: pattern anchored on
# "/" (or start of string) before and a space/end of string after -- by construction excludes a file
# name like "zgc-wine-killer.sh", so no self-kill risk even without the $$/$PPID protection above.
for name in wine wine64 wine-preloader wine64-preloader wineserver winetricks umu-run; do
  count=$(zgc_kill_matching "(^|/)${name}([[:space:]]|\$)")
  [[ -n "${count}" ]] || count=0
  total_killed=$((total_killed + count))
done

# winetricks GUI window. winetricks runs "sh /tmp/winetricks.<random>/w.<user>.<pid>/zenity.sh",
# which starts "zenity" as a child process. The window title is localized (unusable as a
# pattern), but the temp folder name "winetricks.XXXXXXXX/w." is the same in every language.
# The child "zenity" has no trace of winetricks in its command line, so:
#   1. find the "sh .../zenity.sh" process(es) by that stable temp-folder pattern;
#   2. kill that "sh";
#   3. kill its direct children (pgrep -P <pid>): the visible zenity window would otherwise
#      stay open, orphaned.
winetricks_wrapper_pattern="winetricks\.[A-Za-z0-9]+/w\.[^/]+\.[0-9]+/zenity\.sh"
while IFS= read -r wpid; do
  [[ -z "${wpid}" ]] && continue
  [[ "${wpid}" = "${self_pid}" ]] && continue
  [[ "${wpid}" = "${parent_pid}" ]] && continue

  # Direct children FIRST (before killing the parent): once the "sh" is dead its children can no longer
  # be found via pgrep -P (the zenity window would be orphaned under PID 1).
  while IFS= read -r cpid; do
    [[ -z "${cpid}" ]] && continue
    [[ "${cpid}" = "${self_pid}" ]] && continue
    [[ "${cpid}" = "${parent_pid}" ]] && continue
    if kill -9 "${cpid}" 2>/dev/null; then
      total_killed=$((total_killed + 1))
    fi
  done < <(pgrep -P "${wpid}" 2>/dev/null)

  if kill -9 "${wpid}" 2>/dev/null; then
    total_killed=$((total_killed + 1))
  fi
done < <(pgrep -f -- "${winetricks_wrapper_pattern}" 2>/dev/null)

# proton: must be scoped to the Lutris runners folder (see the header: "proton" alone is too generic,
# it could hit ProtonVPN/ProtonMail/Proton Pass).
proton_killed=0
while IFS= read -r pid; do
  [[ -z "${pid}" ]] && continue
  [[ "${pid}" = "${self_pid}" ]] && continue
  [[ "${pid}" = "${parent_pid}" ]] && continue
  cmdline=$(tr '\0' ' ' < "/proc/${pid}/cmdline" 2>/dev/null)
  [[ -z "${cmdline}" ]] && continue
  if [[ "${cmdline}" == *"${lutris_flatpak_runner_dir}"* ]] || [[ "${cmdline}" == *"${lutris_package_runner_dir}"* ]]; then
    if kill -9 "${pid}" 2>/dev/null; then
      proton_killed=$((proton_killed + 1))
    fi
  fi
done < <(pgrep -f -- "proton" 2>/dev/null)
total_killed=$((total_killed + proton_killed))

if [[ "${total_killed}" -gt 0 ]]; then
  zgu_cli_ok "$(t wine_killer.done_cli "${total_killed}")"
  notify-send "$(t wine_killer.notify_title)" "$(t wine_killer.done_gui "${total_killed}")" 2>/dev/null
else
  zgu_cli_ok "$(t wine_killer.nothing_running_cli)"
fi

exit 0
